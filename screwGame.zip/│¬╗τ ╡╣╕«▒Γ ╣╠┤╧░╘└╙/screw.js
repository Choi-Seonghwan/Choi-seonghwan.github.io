let screws = [];
let selectedScrew = null;
let mode = "select"; // "select" 또는 "rotate" 모드
let machineImage;
const holeDepth = 100; // 구멍의 깊이 임의로 설정

// 파티 변수
let shared;
let clickCount;
let rotateDeg;
let selectedScrewIndex;
let tiltCount; // 기울기 카운트

// 이전 기울기 값
let previousBeta = 0;

function preload() {
  partyConnect(
    "wss://demoserver.p5party.org",
    "hello_party"
  );
  shared = partyLoadShared("shared", { x: 100, y: 100 });
  clickCount = partyLoadShared("clickCount", { value: 0 });
  rotateDeg = partyLoadShared("rotate", { value: 0 });
  selectedScrewIndex = partyLoadShared("selectedScrewIndex", { value: -1 });
  tiltCount = partyLoadShared("tiltCount", { value: 0 }); // 기울기 카운트 초기화
  machineImage = loadImage('machine_background.jpg'); // 기계 부품 배경 이미지 로드
}

function setup() {
  createCanvas(800, 600);

  // 나사를 4군데 풀려있는 상태로 생성
  screws.push(new Screw(200, 200));
  screws.push(new Screw(600, 200));
  screws.push(new Screw(200, 400));
  screws.push(new Screw(600, 400));

  if (partyIsHost()) {
    clickCount.value = 0;
    shared.x = 200;
    shared.y = 200;
    rotateDeg.value = 0;
    selectedScrewIndex.value = -1;
    tiltCount.value = 0; // 기울기 카운트 초기화
  }

  // 모바일 기기에서 기울기 데이터 권한 요청
  if (typeof DeviceOrientationEvent !== 'undefined' && DeviceOrientationEvent.requestPermission) {
    createButton('Enable Gyroscope')
      .position(10, 10)
      .mousePressed(() => {
        DeviceOrientationEvent.requestPermission()
          .then(response => {
            if (response === 'granted') {
              window.addEventListener('deviceorientation', handleOrientation);
              console.log('Gyroscope Permission Granted');
            } else {
              console.log('Gyroscope Permission Denied');
            }
          })
          .catch(console.error);
      });
  } else {
    window.addEventListener('deviceorientation', handleOrientation);
  }
}

function handleOrientation(event) {
  console.log('handleOrientation called');
  let beta = event.beta;
  // 기울기 값이 일정 범위 이상 변화할 때만 카운트를 증가
  if (Math.abs(beta - previousBeta) > 1) {
    rotateDeg.value = beta; // 모바일 기기의 기울기 값 갱신
    tiltCount.value++; // 기울기 인식 시 카운트 증가
    previousBeta = beta; // 이전 기울기 값 갱신
    console.log(`Tilt Count: ${tiltCount.value}, Beta: ${beta}`);
  }
}

function draw() {
  background(150);

  // 기계 부품 배경 그리기
  image(machineImage, 0, 0, width, height);

  // 모든 나사를 그림
  for (let i = 0; i < screws.length; i++) {
    screws[i].show();
  }

  // 선택된 나사를 강조 표시
  if (selectedScrewIndex.value !== -1) {
    screws[selectedScrewIndex.value].highlight();
  }

  // 모바일 기기의 기울기를 인식하여 나사를 Y축으로 이동
  if (mode === "rotate" && selectedScrew) {
    selectedScrew.move(rotateDeg.value / 100);
  }

  // 기울기 카운트 표시
  fill(0);
  textSize(32);
  textAlign(CENTER, CENTER);
  text(`Tilt Count: ${tiltCount.value}`, width / 2, height - 50);
}

function mousePressed() {
  selectedScrew = null; // 이전 선택을 초기화
  for (let i = 0; i < screws.length; i++) {
    if (screws[i].isMouseOver()) {
      selectedScrew = screws[i];
      selectedScrewIndex.value = i;
      mode = "rotate";
      break;
    }
  }
}

class Screw {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.size = 50;
    this.depth = 0; // 나사의 구멍 속 깊이
  }

  // 나사 머리와 스크류를 그림
  show() {
    push();
    translate(this.x, this.y + this.depth); // 나사를 아래로 이동

    // 나사 머리 그리기
    noStroke();
    fill(180);
    ellipse(0, 0, this.size, this.size); // 나사 머리의 기본 원

    // 입체감을 위한 음영 효과
    for (let i = 0; i < this.size / 2; i++) {
      let inter = map(i, 0, this.size / 2, 180, 100);
      fill(inter);
      ellipse(0, 0, this.size - i, this.size - i);
    }

    // 나사 슬롯 그리기
    stroke(0);
    strokeWeight(2);
    line(-this.size / 4, -this.size / 4, this.size / 4, this.size / 4);
    line(this.size / 4, -this.size / 4, -this.size / 4, this.size / 4);

    // 나사 스크류 그리기
    stroke(125);
    noFill();
    let threadHeight = 100;
    let threadWidth = 10;
    let threadTurns = 8;
    let spacing = threadHeight / threadTurns;

    beginShape();
    for (let i = 0; i <= threadTurns; i++) {
      let y = i * spacing;
      let x = (i % 2 === 0) ? -threadWidth / 2 : threadWidth / 2;
      vertex(x, y);
    }
    endShape();

    pop();
  }

  // 선택된 나사 강조 표시
  highlight() {
    push();
    translate(this.x, this.y + this.depth); // 강조할 때도 나사를 이동한 위치에 맞춤
    noFill();
    stroke(255, 0, 0);
    strokeWeight(3);
    ellipse(0, 0, this.size + 10, this.size + 10);
    pop();
  }

  // 마우스가 나사 위에 있는지 확인
  isMouseOver() {
    let d = dist(mouseX, mouseY, this.x, this.y + this.depth);
    return d < this.size / 2;
  }

  // 나사 이동
  move(distance) {
    // 나사가 구멍의 깊이를 초과하여 이동하지 않도록 제한
    if (this.depth + distance <= holeDepth) {
      this.depth += distance; // 나사를 구멍 속으로 이동
    } else {
      this.depth = holeDepth; // 구멍의 최대 깊이로 설정
    }
  }
}
